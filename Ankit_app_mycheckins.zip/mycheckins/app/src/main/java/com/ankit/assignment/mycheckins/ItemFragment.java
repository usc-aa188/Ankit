package com.ankit.assignment.mycheckins;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.ankit.assignment.mycheckins.model.Checkin;
import com.ankit.assignment.mycheckins.utils.GpsUtils;
import com.ankit.assignment.mycheckins.utils.Utils;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

public class ItemFragment extends Fragment implements View.OnClickListener, LocationListener, DatePickerDialog.OnDateSetListener {

    private EditText editTitle, editPlace, editDetail;
    private TextView textLocation;
    private ImageView imageView;

    private Button btnAdd, btnDelete, btnShare, btnCapture, btnDate, btnMap;
    private Checkin checkin;

    // temporary variables
    double latitude = 0;
    double longitude = 0;
    String imageData = null;

    private boolean isEdit = false;

    private LocationManager locationManager;

    private static final int MY_CAMERA_PERMISSION_CODE = 101;
    private static final int CAMERA_REQUEST = 102;
    private DatePickerDialog datePickerDialog;

    MainActivity controller;

    View rootView;

    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_item, container, false);
        }

        editTitle = rootView.findViewById(R.id.title);
        editPlace = rootView.findViewById(R.id.place);
        editDetail = rootView.findViewById(R.id.details);

        btnDate = rootView.findViewById(R.id.buttonDate);
        textLocation = rootView.findViewById(R.id.location);
        imageView = rootView.findViewById(R.id.imageView);

        btnShare = rootView.findViewById(R.id.btnShare);
        btnAdd = rootView.findViewById(R.id.btnAdd);
        btnDelete = rootView.findViewById(R.id.btnDelete);
        btnCapture = rootView.findViewById(R.id.btnCapture);
        btnMap = rootView.findViewById(R.id.btnMap);

        btnShare.setOnClickListener(this);
        btnAdd.setOnClickListener(this);
        btnDelete.setOnClickListener(this);
        btnDate.setOnClickListener(this);
        btnCapture.setOnClickListener(this);
        btnMap.setOnClickListener(this);

        controller = (MainActivity)getActivity();
        controller.setActionBarTitle("Item UI");

        locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);

        Bundle bundle=getArguments();

        //here is your list array
        Serializable checkin_data = bundle.getSerializable("checkin");
        if (checkin_data != null) {

            isEdit = true;
            checkin = (Checkin) checkin_data;
            btnDelete.setVisibility(View.VISIBLE);
            btnAdd.setVisibility(View.GONE);

            latitude  = checkin.getLatitude();
            longitude = checkin.getLongitutde();

        } else {

            isEdit = false;
            checkin = new Checkin();
            btnDelete.setVisibility(View.GONE);
            btnAdd.setVisibility(View.VISIBLE);
            getGpsLocation();
        }
        updateView();

        Calendar cal = Calendar.getInstance(TimeZone.getDefault());
        datePickerDialog = new DatePickerDialog(
                getContext(), this, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));

        return rootView;
    }

    private void getGpsLocation() {

        new GpsUtils(getContext()).turnGPSOn(new GpsUtils.onGpsListener() {
            @Override
            public void gpsStatus(boolean isGPSEnable) {
                // turn on GPS

                if (isGPSEnable) {

                    if (checkLocationPermission()) {
                        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 400, 1, ItemFragment.this);
                    }
                }
            }
        });
    }

    public void updateView() {

        editTitle.setText(checkin.getTitle());
        editPlace.setText(checkin.getPlace());
        editDetail.setText(checkin.getDetail());
        btnDate.setText(checkin.getDateString());
        textLocation.setText(checkin.getLocationString());
        Utils.setBase64ToImage(checkin.getImage(), imageView);
    }

    public void saveData() {

        if (isEdit)
            return;

        checkin = new Checkin();

        checkin.setTitle(editTitle.getText().toString());
        checkin.setPlace(editPlace.getText().toString());
        checkin.setDetail(editDetail.getText().toString());
        checkin.setDateString(btnDate.getText().toString());
        checkin.setLatitude(latitude);
        checkin.setLongitutde(longitude);
        checkin.setImage(imageData);

        controller.addCheckin(checkin);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.btnAdd:

                saveData();
                break;

            case R.id.btnDelete:

                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setTitle("Delete item");
                builder.setMessage("Are you sure to delete?");

                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        controller.deleteCheckin(checkin.getId());
                    }
                }).setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        dialogInterface.cancel();
                    }
                });

                builder.create().show();
                break;

            case R.id.btnCapture:
                if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                {
                    ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA}, MY_CAMERA_PERMISSION_CODE);
                }
                else
                {
                    Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(cameraIntent, CAMERA_REQUEST);
                }
                break;
            case R.id.buttonDate: {

                datePickerDialog.show();
                break;
            }
            case R.id.btnMap: {

                Intent intent = new Intent(getActivity(), GoogleMapActivity.class);
                intent.putExtra("latitude", latitude);
                intent.putExtra("longitude", longitude);
                startActivity(intent);
                break;
            }
            case R.id.btnShare: {

                String title = editTitle.getText().toString();
                String place = editPlace.getText().toString();
                String detail = editDetail.getText().toString();
                String date = btnDate.getText().toString();
                String location = textLocation.getText().toString();


                Intent share = new Intent(android.content.Intent.ACTION_SEND);
                share.setType("text/plain");
                share.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
                share.putExtra(Intent.EXTRA_SUBJECT, "MyCheckin - " + title);
                share.putExtra(Intent.EXTRA_TEXT, "Title: " + title + "\nPlace: " + place + "\nDetail: " + detail + "\nDate: " + date + "\nLocation: " + location);

                getContext().startActivity(Intent.createChooser(share, "Share"));
                break;
            }
        }
    }


    // ------------------- LOCATION SERVICE ----------------
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;

    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(getContext(),
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(getContext())
                        .setTitle(R.string.title_location_permission)
                        .setMessage(R.string.text_location_permission)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(getActivity(),
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(getContext(),
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        //Request location updates:
                        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 400, 1, this);
                    }

                } else {
                }
                return;
            }
            case MY_CAMERA_PERMISSION_CODE: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
                {
//                    Toast.makeText(this, "Camera permission granted", Toast.LENGTH_LONG).show();
                    Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(cameraIntent, CAMERA_REQUEST);
                }
                else
                {
                    Toast.makeText(getContext(), "Camera permission denied", Toast.LENGTH_LONG).show();
                }
            }

        }
    }

    @Override
    public void onLocationChanged(Location location) {

        if (location != null && location.getLatitude() != 0 && location.getLongitude() != 0) {

            latitude = location.getLatitude();
            longitude = location.getLongitude();
            textLocation.setText("" + latitude + ", " + longitude);
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK)
        {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            imageView.setImageBitmap(photo);
            imageData = Utils.imageToBase64(photo);
        }
        if (requestCode == GpsUtils.GPS_REQUEST && resultCode == Activity.RESULT_OK) {

            if (checkLocationPermission()) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 400, 1, ItemFragment.this);
            }
        }
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, dayOfMonth);

        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        String strDate = format.format(calendar.getTime());

        btnDate.setText(strDate);
    }
}
