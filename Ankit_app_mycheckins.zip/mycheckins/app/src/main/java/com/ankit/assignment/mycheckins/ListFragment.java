package com.ankit.assignment.mycheckins;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.ankit.assignment.mycheckins.model.Checkin;

import java.util.ArrayList;
import java.util.List;

public class ListFragment extends Fragment implements AdapterView.OnItemClickListener {

    private ListView listView;

    private List<Checkin> listCheckins = new ArrayList<Checkin>();

    private Toolbar mTopToolbar;
    private CheckinListAdapter adapter;

    MainActivity controller;

    View rootView;

    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_list, container, false);
        }

        listView = rootView.findViewById(R.id.listCheckins);

        adapter = new CheckinListAdapter(getContext());
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);

        controller = (MainActivity)getActivity();
        controller.setActionBarTitle("List UI");

        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();

        updateList();
    }


    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

        if(position > -1) {
            controller.showItemUI(listCheckins.get(position).getId());
        }

    }

    private void updateList() {

        listCheckins = controller.getCheckins();
        adapter.notifyDataSetChanged();
    }

    public class CheckinListAdapter extends BaseAdapter {

        private Context mContext;

        public CheckinListAdapter(Context context) {
            super();
            this.mContext = context;
        }

        @Override
        public int getCount() {
            return listCheckins.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            View v = convertView;

            if (v == null) {
                v = LayoutInflater.from(mContext).inflate(R.layout.listview_item, null);
            }

            Checkin p = listCheckins.get(position);

            if (p != null) {
                TextView textTitle = v.findViewById(R.id.textTitle);
                TextView textDate = v.findViewById(R.id.textDate);
                TextView textPlace = v.findViewById(R.id.textPlace);

                textTitle.setText(p.getTitle());
                textDate.setText(p.getDateString());
                textPlace.setText(p.getPlace());
            }

            return v;
        }

    }
}
