package com.ankit.assignment.mycheckins.model;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHandler extends SQLiteOpenHelper {

    private static final String DATABASE_NAME="CheckinManager";
    private static final String TABLE_NAME="checkin";
    private static final String KEY_ID="id";
    private static final String KEY_TITLE="title";
    private static final String KEY_PLACE="place";
    private static final String KEY_DETAILS="details";
    private static final String KEY_DATE="date";
    private static final String KEY_LATITUDE="latitude";
    private static final String KEY_LONGITUDE="longitude";
    private static final String KEY_IMAGE="image";

    private final static String CREATE_TABLE= "CREATE TABLE "+TABLE_NAME+
            " ("+KEY_ID+" integer primary key autoincrement," +
            KEY_TITLE +" text not null, "+KEY_PLACE +" text not null, " +
            KEY_DETAILS + " text not null, " + KEY_DATE +" text not null, " +
            KEY_LATITUDE+" real not null, " + KEY_LONGITUDE+" real not null, " +
            KEY_IMAGE+" text not null)";

    private SQLiteDatabase db;

    public DatabaseHandler(Context ctx) {
        super(ctx, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion != newVersion) {
            db.execSQL("drop table " + DATABASE_NAME);
            this.onCreate(db);
        }
    }

    public SQLiteDatabase openDB() {
        db = this.getWritableDatabase();
        return db;
    }

    public void closeDB() { db.close(); }

    public long addCheckin(Checkin checkin) {
        db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(KEY_TITLE, checkin.getTitle());
        contentValues.put(KEY_PLACE, checkin.getPlace());
        contentValues.put(KEY_DETAILS, checkin.getDetail());
        contentValues.put(KEY_DATE, checkin.getDateString());
        contentValues.put(KEY_LATITUDE, checkin.getLatitude());
        contentValues.put(KEY_LONGITUDE, checkin.getLongitutde());
        contentValues.put(KEY_IMAGE, checkin.getImage());
        return db.insert(TABLE_NAME, null, contentValues);
    }

    public List<Checkin> getCheckins() {
        List<Checkin> checkinList = new ArrayList<>();
        db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM "+TABLE_NAME, null);

        if(cursor.getCount() == 0) return new ArrayList<>(0);
        cursor.moveToFirst();

            do {
                Checkin checkin = new Checkin();
                checkin.setId(Integer.parseInt(cursor.getString(0)));
                checkin.setTitle(cursor.getString(1));
                checkin.setPlace(cursor.getString(2));
                checkin.setDetail(cursor.getString(3));
                checkin.setDateString(cursor.getString(4));
                checkin.setLatitude(Double.parseDouble(cursor.getString(5)));
                checkin.setLongitutde(Double.parseDouble(cursor.getString(6)));
                checkin.setImage(cursor.getString(7));
                checkinList.add(checkin);
            } while(cursor.moveToNext());

        cursor.close();
        return checkinList;
    }

    public void deleteCheckin(int id) {
        db = this.getWritableDatabase();
        String sql = "DELETE FROM "+TABLE_NAME+" WHERE "+KEY_ID + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{"" + id});
        cursor.moveToFirst();
        cursor.close();
    }

    public Serializable getCheckin(int id) {

        db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE "+KEY_ID + " = ?", new String[]{"" + id});

        if(cursor.getCount() == 0)
            return null;

        cursor.moveToFirst();

        Checkin checkin = new Checkin();
        checkin.setId(Integer.parseInt(cursor.getString(0)));
        checkin.setTitle(cursor.getString(1));
        checkin.setPlace(cursor.getString(2));
        checkin.setDetail(cursor.getString(3));
        checkin.setDateString(cursor.getString(4));
        checkin.setLatitude(Double.parseDouble(cursor.getString(5)));
        checkin.setLongitutde(Double.parseDouble(cursor.getString(6)));
        checkin.setImage(cursor.getString(7));

        cursor.close();

        return checkin;
    }
}
