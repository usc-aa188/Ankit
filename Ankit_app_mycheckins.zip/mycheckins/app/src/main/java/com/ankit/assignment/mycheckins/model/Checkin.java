package com.ankit.assignment.mycheckins.model;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Checkin implements Serializable {

    private int id;
    private String title, place, detail;
    private Date date;
    private double latitude;
    private double longitutde;
    private String image;

    public Checkin() {
        id = 0;
        title = "";
        place = "";
        detail = "";
        date = new Date();
        latitude = 0;
        longitutde = 0;
        image = "";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitutde() {
        return longitutde;
    }

    public void setLongitutde(double longitutde) {
        this.longitutde = longitutde;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }


    // Util methods
    public String getLocationString() {
        return "lat: " + latitude + ", lon: " + longitutde;
    }

    public String getDateString() {

        if (date == null)
            return "";

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String dateTime = "";
        try {
            dateTime = dateFormat.format(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dateTime;
    }

    public void setDateString(String strDate) {

        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        this.date = null;
        try {
            this.date = format.parse(strDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String toString() {
        return id + " " + title + " " + place;
    }
}
