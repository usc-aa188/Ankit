package com.ankit.assignment.mycheckins.utils;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.widget.ImageView;

import com.ankit.assignment.mycheckins.model.Checkin;

import java.io.ByteArrayOutputStream;

public class Utils {

    public static String imageToBase64(Bitmap bitmap) {

        ByteArrayOutputStream stream=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream);
        byte[] image=stream.toByteArray();

        String strBase64 = Base64.encodeToString(image, 0);
        return strBase64;
    }

    public static void setBase64ToImage(String strBase64, ImageView imageView) {

        byte[] decodedString = Base64.decode(strBase64, Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        imageView.setImageBitmap(decodedByte);
    }

    public static String makeSummary(Checkin checkin) {

        if (checkin == null)
            return "";
        String summary = "";
        return summary;
    }
}
